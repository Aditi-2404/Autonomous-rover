# autonomous-rover
Autonomous traversal of Martian Rover - for Team RoverX

https://github.com/AtsushiSakai/PythonRobotics
