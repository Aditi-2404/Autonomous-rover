import serial
import urllib

ser = serial.Serial('COM1',115200)

temp = ''
s = ''

while True:
    ch = ser.read()
    print(ch.decode())
    #s += ch.decode()
    s = ch
    #if ch.decode()!='':
        #print(ch.decode(),end='')
    '''
    if len(s)>6:
        print('entering',s)
        if len(s)>6:
            if ('N' in s or 'S' in s) and ('E' in s or 'W' in s):
                sn = ''
                se = ''
                if 'N' in s:
                    char = 'N'
                else:
                    char = 'S'
                    
                if len(s[::-1][s[::-1].index(char)+2:][:s[::-1][s[::-1].index(char)+2:].index(',')][::-1]) == 9:
                    sn = (s[::-1][s[::-1].index(char)+2:][:s[::-1][s[::-1].index(char)+2:].index(',')][::-1])

                if 'E' in s:
                    char = 'E'
                else:
                    char = 'W'

                if len(s[::-1][s[::-1].index(char)+2:][:s[::-1][s[::-1].index(char)+2:].index(',')][::-1]) == 10:
                    se = (s[::-1][s[::-1].index(char)+2:][:s[::-1][s[::-1].index(char)+2:].index(',')][::-1])

                if len(sn)>0 and len(se)>0:
                    print('Pretty',sn)
                    print('Pretty',se)
                #print('-')
    else:
        print(s)
        s = ''
    '''
