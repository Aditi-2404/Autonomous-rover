import math
import time
def go(direction, position):

    position[0]+=direction[0]
    position[1]+=direction[1]

    return position

def getAngle():
    global finalx, finaly
    #time.sleep(2)
    finalx = 10
    finaly = 0
    
    oldx, oldy = [20,0]
    currentx, currenty = oldx, oldy
    t = 0
    direction = [1,0]
    # Go forward for at most 4 seconds
    while True or obstacleAhead()==0:
        currentx, currenty = go(direction, [currentx, currenty])
        t+=1
        #print('current',currentx,currenty)
        if t==5:
            break
    #currentx, currenty = oldx, oldy
    #currentx+=1
    #currenty+=1

    # Vector made by (oldx, oldy) to (currentx, currenty)
    A = [currentx - oldx, currenty - oldy]

    # Vector made by (oldx, oldy) to (finalx, finaly)
    B = [finalx - oldx, finaly - oldy]
    print('vectors',A,B)
    # Vector made by (currentx, currenty) to (finalx, finaly)
    # A + C = B
    # Therefore, C = B - A
    C = [0, 0]
    C[1] = B[1] - A[1]
    C[0] = B[0] - A[0]

    ''' To find the angle between A and C                  '''
    ''' calculate the dot product of A and C/mag(A)*mag(C) '''


    # Dot Product
    costheta_numerator = A[0]*C[0] + A[1]*C[1]
    costheta_denominator = ((A[0]**2 + A[1]**2)**0.5) * ((C[0]**2 + C[1]**2)**0.5)
    #print('numerator',costheta_numerator,'\n','denominator',costheta_denominator)
    if costheta_denominator == 0:
        # Recursively keep trying till you get a valid direction vector
        return getAngle()
    
    costheta = costheta_numerator/costheta_denominator
    #print('costheta',costheta)
    #print(oldx, oldy, currentx, currenty, finalx, finaly)
    angle = math.degrees(math.acos(costheta))
    print('Angle function returning',angle)

    # Cross Product
    sintheta_numerator = A[0]*C[1] - A[1]*C[0]
    sintheta_denominator = costheta_denominator

    sintheta = sintheta_numerator/sintheta_denominator
    #print('sintheta',sintheta)
    sinangle = math.degrees(math.asin(sintheta))
    #print('sin angle',sinangle)
    if sinangle<0:
        print('Clockwise')
    else:
        print('Anticlockwise')
    
    return angle
