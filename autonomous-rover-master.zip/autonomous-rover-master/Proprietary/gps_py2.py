import serial
import urllib
ser = serial.Serial('COM1',9600)
temp = ''



while True:
    f = open("readings1.txt","a")
    ch = ser.read()
    ultrasonic = ''
    while ch[0]!=13:
        ultrasonic += chr(ch[0])
        ch = ser.read()
    ch = ser.read()
    longitude = ''
    while ch[0]!=13:
        ch = ser.read()
        longitude += chr(ch[0])
        
    ch = ser.read()
    latitude = ''
    while ch[0]!=13:
        ch = ser.read()
        latitude+=chr(ch[0])
        
    ch = ser.read()
    print('Ultrasonic:',ultrasonic)
    print('Longitude:', longitude)
    print('Latitude:', latitude)
    f.write('Ultrasonic: ' + str(ultrasonic) + '\n')
    f.write('Longitude: ' + str(longitude) + '\n')
    f.write('Latitude: ' + str(latitude) + '\n')
    #f.flush()
    f.close()
    

#f.close()
