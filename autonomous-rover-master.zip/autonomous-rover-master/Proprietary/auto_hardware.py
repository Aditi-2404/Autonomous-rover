import time
import math
from collections import defaultdict
import marker_detection


'''
----------------------------------------------------------------------------------------
Methods used:
----------------------------------------------------------------------------------------
getGPS() : gets current GPS coordinates
nearGoal() : checks if rover is near enough to the goal to engage computer vision algos
obstacleAhead() : informs whether there's an obstacle in front of the rover
go(Time) : instructs the rover to move forward
getAngle() : instructs the rover to calculate angle of deviation and course-correct
getGoal() : reads in destination coordinates
do() : invokes all the above functions and is the main code
-----------------------------------------------------------------------------------------
'''

'''
getGPS():
Returns current GPS coordinates
----------------------------------------------------------------------------------------
'''
def getGPS():
    f = open('readings1.txt','r')
    s = f.readlines()
    #print(s[-6:])
    f.close()
    return (float(s[-4][11:-1])*10000, float(s[-2][10:-1])*10000)

def getUltrasonic():
    f = open('readings1.txt','r')
    s = f.readlines()
    #print(s[-6:])
    f.close()
    return int(s[-5][12:-1])
'''
nearGoal():
Returns 1 if Rover is within X meters of final destination
----------------------------------------------------------------------------------------
'''
def nearGoal():
    global currentx, currenty, finalx, finaly
    ERROR_RANGE = 100

    if abs(finalx*10000-currentx*10000)<=ERROR_RANGE and abs(finaly*10000-currenty*10000)<=ERROR_RANGE:
        return 1
    else:
        return 0
    


'''
obstacleAhead():
Returns 1 if there is an obstacle detected in front of the rover
Else returns 0
----------------------------------------------------------------------------------------
'''
def obstacleAhead():
    THRESHOLD = 10
    if getUltrasonic() < THRESHOLD:
        return 1
    return 0

'''
go(Time):
Instructs the rover to move forward in its current direction
for a duration of parameter "Time" seconds
----------------------------------------------------------------------------------------
'''
def go(Time):
    while Time>0:
        print('Forward')
        print(getGPS())
        time.sleep(1)
        Time -= 1

'''
getAngle():
Calculates required angle to be turned, to face destination
----------------------------------------------------------------------------------------
'''
def getAngle():
    global finalx, finaly
    oldx, oldy = getGPS()
    t = 0

    # Go forward for at most 4 seconds
    while obstacleAhead()==0:
        go(t)
        t+=1
        if t==5:
            break
    currentx, currenty = getGPS()
    #currentx+=1
    #currenty+=1

    # Vector made by (oldx, oldy) to (currentx, currenty)
    A = [currentx - oldx, currenty - oldy]

    # Vector made by (oldx, oldy) to (finalx, finaly)
    B = [finalx - oldx, finaly - oldy]

    # Vector made by (currentx, currenty) to (finalx, finaly)
    # A + C = B
    # Therefore, C = B - A
    C = [0, 0]
    C[1] = B[1] - A[1]
    C[0] = B[0] - A[0]

    ''' To find the angle between A and C                  '''
    ''' calculate the dot product of A and C/mag(A)*mag(C) '''
    
    costheta_numerator = A[0]*C[0] + A[1]*C[1]
    costheta_denominator = ((A[0]**2 + A[1]**2)**0.5) * ((C[0]**2 + C[1]**2)**0.5)

    if costheta_denominator == 0:
        # Recursively keep trying till you get a valid direction vector
        return getAngle()

    costheta = costheta_numerator/costheta_denominator

    angle = math.degrees(math.acos(costheta))
    print('Angle function returning',angle)

    # Cross Product
    sintheta_numerator = A[0]*C[1] - A[1]*C[0]
    sintheta_denominator = costheta_denominator
    sintheta = sintheta_numerator/sintheta_denominator
    
    sinangle = math.degrees(math.asin(sintheta))
    
    if sinangle<0:
        print('Working Direction: Anticlockwise')
    else:
        print('Working Direction: Clockwise')
    
    return angle

def getCurrentAngle():
    f = open('anglereadings.txt','r')
    x = f.readlines()
    print(x[-1:])
    

'''
turnRover(angle):
Instructs rover to turn by an angle of parameter "angle"
----------------------------------------------------------------------------------------
'''
def turnRover(angle):
    currentangle = getCurrentAngle() + 180
    print('Current angle:',currentangle)
    if angle<0:
        #turn counterclockwise
        finalangle = (currentangle - angle)
        if finalangle<0:
            finalangle+=360
        print('Turn rover to angle', finalangle)
    else:
        #turn clockwise
        finalangle = (currentangle + angle)
        if finalangle>=360:
            finalangle-=360
            
        print('Turn rover to angle', finalangle)

'''
getGoal():
Reads in destination coordinates
----------------------------------------------------------------------------------------
'''
def getGoal():
    global finalx, finaly, currentx, currenty
    print(getGPS())
    currentx, currenty = getGPS()
    print('Enter final co-ordinates: ')
    finalx, finaly = [float(i) for i in input().split(" ")]

'''
detectMarker():
Engage opencv code to find marker
----------------------------------------------------------------------------------------
'''
def detectMarker():
    marker_detection.doopencv()
    
    return 0
'''
do():
Main function that does all the work
----------------------------------------------------------------------------------------
'''
def do():
    getGoal()
    time.sleep(3)

    currentx, currenty = getGPS()
    '''
    # Treat as a stack, LIFO data structure to store
    # whenever decisions were made of going Left or Right.
    # This is used to backtrack and attempt to
    # return to past location if confidence has reached zero.
    '''
    previousObstacles = defaultdict(int)
    initTime = time.time()
    pathStack = []
    while not nearGoal():
        if obstacleAhead():

            print('Waiting for 3 seconds')  #Wait to allow GPS to calibrate
            time.sleep(3)
            
            currentx, currenty = getGPS()

            # If new location and first time making choice, add it to stack
            previousObstacles[((currentx)//10, (currenty)//10)] += 1
            pathStack.append(((currentx)//10, (currenty)//10))
            # If choice is being made for first time
            if previousObstacles[pathStack[-1]] == 1:
                ct = 0
                pathStack.append((currentx, currenty))
                direction = 1
            # If choice is being made for second time
            elif previousObstacles[pathStack[-1]] == 2:
                direction = -1
                pathStack.remove((currentx//10, currenty//10))
            
            while obstacleAhead():
                turnRover(1*direction)
                time.sleep(1)
                ct += 1
                if abs(ct)>=90:
                    direction *= (-1)
            print('Total turning angle:',ct)
            start = time.time()
            while obstacleAhead()==0:
                go(1)
                angleNeeded = getAngle()
                print('Angle needed:',angleNeeded)
            
                #turn and check ideal direction every 3 seconds

                if obstacleAhead()==0:
                    continue
                if (time.time() - start)%3 == 0:
                    turnRover(-1*direction*angleNeeded)
                #else:
                #    turnRover(direction*angleNeeded)
        else:
            go(1)
            if (time.time() - initTime)>3:
                angleNeeded = getAngle()
                initTime = time.time()
                print('Angle needed:',angleNeeded)
                turnRover(angleNeeded)
    if nearGoal():
        detectMarker()
                
            
if __name__ == "__main__":

    # In the name of the Gods of Autonomous Traversal for Martian Rovers - Please do not crash our Rover
    do()
