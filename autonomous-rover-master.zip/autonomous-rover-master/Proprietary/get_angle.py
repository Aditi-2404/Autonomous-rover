import serial
import urllib

def doangle():
    ser = serial.Serial('COM5',9600)
    temp = ''


    #COM5
    f = open("anglereadings.txt","w")
    f.close()
    while True:
        f = open("anglereadings.txt","a")
        cur = ''
        ch = ser.read().decode('utf-8')
    #   print(ch)
        while len(ch)>0 and ch!='\r':
            #while ch=='-':
            #    ch = ser.read().decode('utf-8')
            if ch=='.' or ch=='\n' or ch=='-':
                cur+=ch
            else:
                cur+=str(int(ch))
            ch = ser.read().decode('utf-8')
        print(cur)
        if cur=='\n' or cur.count('.')==2:
            continue
        else:
            f.write(cur)
        f.close()
        

    #f.close()
