'''
Problems - Obstacle avoidance, marker recognition, GPS may be vague, if it can go thru location
Assumption -  No backtracking
store GPS for -
In practice - store GPS most recent 3600 coordinates at 1 coordinate per second -


pseudocode -

first store initial co-ordinate, start moving for 5 seconds, wait 2 secs - acquire optimal angle

Once optimal angle acquired -
realign to optimal angle, and start moving in that direction - constantly calculate optimal angle and realign 
if object is present, save current coordinate in ambiguity array, try going around object and then recalculate angle

map angle by time
'''

import random
from collections import defaultdict
rows = 30
cols = 20
gri = [ ['.' for i in range(cols)] for j in range(rows)]
roverx = 0
rovery = 0
finalx = 0
finaly = 0
test = 0
path_taken = []
visited = defaultdict(int)

def issafe(x,y):
    return x>=0 and x<=29 and y>=0 and y<=19 and gri[x][y]!='X' and gri[x][y]!='#' and gri[x][y]!='R'

def euclid(x1, y1, x2, y2):
    return (x2-x1)**2 + (y2-y1)**2

def populate():

    global gri
    gri = [ ['.' for i in range(cols)] for j in range(rows)]
    for i in range(100):
        x = 1+random.randint(0,27)
        y = 1+random.randint(0,17)
        gri[x][y] = 'X'

def place_rover():

    global roverx, rovery
    roverx = random.randint(0,29)
    rovery = random.randint(0,19)
    gri[roverx][rovery] = 'R'

def place_destination():

    global finalx, finaly
    finalx = random.randint(0,29)
    finaly = random.randint(0,19)
    gri[finalx][finaly] = 'F'
    #print('original')
    #for i in gri:
    #    print(*i)

def takenthbestroute(time):

    global path_taken,finalx,finaly
    motions = [ [0,0], [-1, -1], [-1, 0], [0, -1], [1, -1], [1, 0], [1,1], [0,1], [-1,1] ]
    #if(len(path_taken)>5):
    #    prev_x,prev_y = path_taken[-5]
    #else:
    #    prev_x,prev_y = path_taken[len(path_taken)-2]
    prev_x, prev_y = path_taken[-time]
    #print('In nth best fn', prev_x, prev_y)
    map_coord = defaultdict(float)
    dist = []
    for i in range(len(motions)):
        check_x = prev_x+motions[i][0]
        check_y = prev_y = motions[i][1]
        dist_value = euclid(check_x,check_y,finalx,finaly)
        map_coord[dist_value] = i
        dist.append(dist_value)
    dist.sort()
    ind  = map_coord[dist[time]]
    return ind
    
        
   #in practice get all valid spaces to go thru and find nth best route from them
orig = []
def path():
    
    global roverx, rovery, finalx, finaly, gri, orig

    # ID valid angles from LIDAR (or 8 neighbors), and then perform below algo only on them
    # Make sure rover TURNS and only then moves in its direction
    test = 0
    while (roverx!=finalx or rovery!=finaly):
        path_taken.append([roverx, rovery])
        visited[(roverx, rovery)] += 1
        xx = roverx
        yy = rovery
        fy = finaly
        fx = finalx
        current_dist = euclid(xx, yy, fx, fy)
        if_case_no = 0
        min_dist = current_dist

        #iterate over valid widths and find minimum euclidean distance, proceed accordingly
        if issafe(xx-1, yy-1) and euclid(xx-1, yy-1, fx, fy) <= min_dist:
            if_case_no = 1
            min_dist = euclid(xx-1, yy-1, fx, fy)

        if issafe(xx-1, yy) and euclid(xx-1, yy, fx, fy) <= min_dist:
            if_case_no = 2
            min_dist = euclid(xx-1, yy, fx, fy)
            
            
        if issafe(xx, yy-1) and euclid(xx, yy-1, fx, fy) <= min_dist:
            if_case_no = 3
            min_dist = euclid(xx, yy-1, fx, fy)
            
        if issafe(xx+1, yy-1) and euclid(xx+1, yy-1, fx, fy) <= min_dist:
            if_case_no = 4
            min_dist = euclid(xx+1, yy-1, fx, fy)
            
        if issafe(xx+1, yy) and euclid(xx+1, yy, fx, fy) <= min_dist:
            if_case_no = 5
            min_dist = euclid(xx+1, yy, fx, fy)
    
        if issafe(xx+1, yy+1) and euclid(xx+1, yy+1, fx, fy) <= min_dist:
            if_case_no = 6
            min_dist = euclid(xx+1, yy+1, fx, fy)
            
        if issafe(xx, yy+1) and euclid(xx, yy+1, fx, fy) <= min_dist:
            if_case_no = 7
            min_dist = euclid(xx, yy+1, fx, fy)
    
        if issafe(xx-1, yy+1) and euclid(xx-1, yy+1, fx, fy) <= min_dist:
            if_case_no = 8
            min_dist = euclid(xx-1, yy, fx, fy)

        if if_case_no == 0:
            min_dist = 10**9
            
            #iterate over valid widths and find minimum euclidean distance, proceed accordingly
            if issafe(xx-1, yy-1) and euclid(xx-1, yy-1, fx, fy) <= min_dist:
                if_case_no = 1
                min_dist = euclid(xx-1, yy-1, fx, fy)

            if issafe(xx-1, yy) and euclid(xx-1, yy, fx, fy) <= min_dist:
                if_case_no = 2
                min_dist = euclid(xx-1, yy, fx, fy)
                
                
            if issafe(xx, yy-1) and euclid(xx, yy-1, fx, fy) <= min_dist:
                if_case_no = 3
                min_dist = euclid(xx, yy-1, fx, fy)
                
            if issafe(xx+1, yy-1) and euclid(xx+1, yy-1, fx, fy) <= min_dist:
                if_case_no = 4
                min_dist = euclid(xx+1, yy-1, fx, fy)
                
            if issafe(xx+1, yy) and euclid(xx+1, yy, fx, fy) <= min_dist:
                if_case_no = 5
                min_dist = euclid(xx+1, yy, fx, fy)
        
            if issafe(xx+1, yy+1) and euclid(xx+1, yy+1, fx, fy) <= min_dist:
                if_case_no = 6
                min_dist = euclid(xx+1, yy+1, fx, fy)
                
            if issafe(xx, yy+1) and euclid(xx, yy+1, fx, fy) <= min_dist:
                if_case_no = 7
                min_dist = euclid(xx, yy+1, fx, fy)
        
            if issafe(xx-1, yy+1) and euclid(xx-1, yy+1, fx, fy) <= min_dist:
                if_case_no = 8
                min_dist = euclid(xx-1, yy, fx, fy)
        
        motions = [ [0,0], [-1, -1], [-1, 0], [0, -1], [1, -1], [1, 0], [1,1], [0,1], [-1,1] ]
        
        motion_coordinate = if_case_no
        if(visited[(roverx,rovery)]>2):
            motion_coordinate = takenthbestroute(visited[(roverx, rovery)]-1)
            test = 1
            #print('oh')
            #for i in path_taken:
            #    print(*i)
            
        xx = xx+motions[motion_coordinate][0]
        yy = yy+motions[motion_coordinate][1]
    
        roverx = xx
        rovery = yy
        if xx==finalx and yy==finaly:
            break
        #if test:
          #  print('hashing at',xx,yy)
        gri[xx][yy] = '#'
    #if test:
        #print('or')
        #for i in orig:
        #    print(*i)
        #print('final')
        #for i in gri:
         #   print(*i)
        
    gri[finalx][finaly] = 'F'
    
    
def print_map():

    global gri
    for i in gri:
        print(*i)

def success():
    ok = 0
    motions = [ [0,0], [-1, -1], [-1, 0], [0, -1], [1, -1], [1, 0], [1,1], [0,1], [-1,1] ]
    for i in range(len(motions)):
        if issafe(finalx + motions[i][0], finaly+motions[i][1]) and gri[finalx+motions[i][0]][finaly+motions[i][1]] == '#':
            ok = 1
        
    return ok

for t in range(500000):
    path_taken = []
    visited = defaultdict(int)
    #if t%10 == 0:
    if t%1000 == 0:
        print(t)
    #print(t)
    populate()
    place_rover()
    place_destination()
    orig = [['' for i in range(len(gri[0]))] for j in range(len(gri))]
    for i in range(len(gri)):
        for j in range(len(gri[0])):
            orig[i][j] = gri[i][j]
    test = 0
    path()
    if success()==1:
        print_map()
    #for i in path_taken:
    #    print(i[0],i[1])
    #print('-'*40)
    #if test:
    #    for i in gri:
    #        print(*i)
    #    
    #    break
print('Done')
